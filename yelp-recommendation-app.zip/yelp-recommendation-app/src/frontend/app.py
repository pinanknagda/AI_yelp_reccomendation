import streamlit as st
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from src.data_processing.spark_setup import initialize_spark
from src.data_processing.data_loader import load_data
from src.embeddings.vector_store import VectorStore
from src.rag.rag_chain import RAGChain


def main():
    st.title("Yelp Recommendation App")
    sc , spark = initialize_spark()
    sc.setLogLevel("DEBUG")  # Set log level to DEBUG

    # Load data and initialize vector store
    reviews_df, business_df = load_data(spark=  spark, reviews_file_path="data/yelp_academic_dataset_review.json", 
                                        business_file_path="data/yelp_academic_dataset_business.json")
    vector_store = VectorStore(reviews_df)
    rag_chain = RAGChain(vector_store)

    user_query = st.text_input("Enter your query about restaurants:")
    
    if st.button("Get Recommendations"):
        if user_query:
            recommendations = rag_chain.get_recommendations(user_query)
            st.write("### Recommendations:")
            for rec in recommendations:
                st.write(rec)
        else:
            st.warning("Please enter a query.")

if __name__ == "__main__":
    main()