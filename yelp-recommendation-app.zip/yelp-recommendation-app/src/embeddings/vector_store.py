from langchain_chroma import Chroma
from langchain_openai import OpenAIEmbeddings
import os

class VectorStore:
    def __init__(self, collection_name: str, persist_directory: str):
        openai_api_key = os.environ["OPENAI_API_KEY"]
        self.embeddings = OpenAIEmbeddings(openai_api_key=openai_api_key)
        self.vector_store = Chroma(
            collection_name=collection_name,
            embedding_function=self.embeddings,
            persist_directory=persist_directory
        )

    def add_embeddings(self, ids: list, documents: list):
        self.vector_store.add(ids=ids, documents=documents)

    def query_embeddings(self, query: str, k: int = 5):
        return self.vector_store.query(query, k=k)

