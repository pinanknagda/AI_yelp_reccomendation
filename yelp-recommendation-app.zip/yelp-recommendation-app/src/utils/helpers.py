import os

def load_env_variables():
    """Load environment variables from the .env file."""
    from dotenv import load_dotenv
    load_dotenv()

def get_openai_api_key():
    """Retrieve the OpenAI API key from environment variables."""
    return os.getenv("OPENAI_API_KEY")

def validate_dataframe(df, required_columns):
    """Validate that the DataFrame contains the required columns."""
    missing_columns = [col for col in required_columns if col not in df.columns]
    if missing_columns:
        raise ValueError(f"Missing required columns: {', '.join(missing_columns)}")

def clean_text(text):
    """Clean and preprocess the review text."""
    import re
    text = re.sub(r'\s+', ' ', text)  # Replace multiple spaces with a single space
    text = text.strip()  # Remove leading and trailing spaces
    return text

