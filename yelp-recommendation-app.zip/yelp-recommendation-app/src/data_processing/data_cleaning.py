import os
from pyspark.sql import DataFrame
from pyspark.sql.functions import lower, col

def clean_business_data(business_df: DataFrame) -> DataFrame:
    """
    Cleans the business DataFrame by dropping unnecessary columns and filtering for open restaurants.
    """
    business_df = business_df.drop('attributes', 'hours')
    business_df = business_df.where(lower(col('Categories')).rlike('.*restaurant.*'))
    return business_df.filter(col('is_open') == 1)

def remove_outliers(dataframe: DataFrame, column: str, factor: float = 1.5) -> DataFrame:
    """
    Removes outliers from the specified column in the DataFrame using the IQR method.
    """
    quartiles = dataframe.approxQuantile(column, [0.25, 0.75], 0.25)
    q1, q3 = quartiles[0], quartiles[1]
    iqr = q3 - q1
    lower_bound = q1 - factor * iqr
    upper_bound = q3 + factor * iqr
    return dataframe.filter((col(column) >= lower_bound) & (col(column) <= upper_bound))

def clean_review_data(reviews_df: DataFrame) -> DataFrame:
    """
    Cleans the reviews DataFrame by selecting necessary columns.
    """
    return reviews_df.select(col('review_id'), col('text'))

def preprocess_data(business_df: DataFrame, reviews_df: DataFrame) -> DataFrame:
    """
    Preprocesses the business and reviews DataFrames and returns the cleaned DataFrame.
    """
    cleaned_business_df = clean_business_data(business_df)
    cleaned_business_df = remove_outliers(cleaned_business_df, 'review_count')
    cleaned_reviews_df = clean_review_data(reviews_df)
    
    return cleaned_business_df.join(cleaned_reviews_df, cleaned_reviews_df.business_id == cleaned_business_df.business_id, "left")