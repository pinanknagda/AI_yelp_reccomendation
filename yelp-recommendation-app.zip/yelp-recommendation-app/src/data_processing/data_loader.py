from pyspark.sql import SparkSession

def load_reviews_data(spark: SparkSession, file_path: str):
    """
    Load the Yelp reviews dataset into a Spark DataFrame.
    
    Parameters:
    - spark: SparkSession object
    - file_path: Path to the JSON file containing the reviews data
    
    Returns:
    - DataFrame containing the reviews data
    """
    return spark.read.json(file_path)

def load_business_data(spark: SparkSession, file_path: str):
    """
    Load the Yelp business dataset into a Spark DataFrame.
    
    Parameters:
    - spark: SparkSession object
    - file_path: Path to the JSON file containing the business data
    
    Returns:
    - DataFrame containing the business data
    """
    return spark.read.json(file_path)

def load_data(spark: SparkSession, reviews_file_path: str, business_file_path: str):
    """
    Load both the Yelp reviews and business datasets into Spark DataFrames.
    
    Parameters:
    - spark: SparkSession object
    - reviews_file_path: Path to the JSON file containing the reviews data
    - business_file_path: Path to the JSON file containing the business data
    
    Returns:
    - Tuple of DataFrames containing the reviews and business data
    """
    reviews_df = load_reviews_data(spark, reviews_file_path)
    business_df = load_business_data(spark, business_file_path)
    return reviews_df, business_df