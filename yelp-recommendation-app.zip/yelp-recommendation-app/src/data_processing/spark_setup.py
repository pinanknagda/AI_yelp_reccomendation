import os
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession
import findspark


def initialize_spark(app_name="Yelp Recommendation App"):
    os.environ['JAVA_HOME'] = 'C:\\Program Files\\Java\\jdk-17'
    os.environ['SPARK_HOME'] = 'C:\\spark-3.5.4'
    findspark.init()
    conf = SparkConf() \
        .setAppName(app_name) \
        .setMaster("local[*]") \
        .set("spark.driver.host", "192.168.1.245") \
        .set("spark.driver.bindAddress", "192.168.1.245") \
        .set("spark.driver.memory", "4g") \
        .set("spark.executor.memory", "4g") \
        .set("spark.sql.shuffle.partitions", "4000") \
        .set("spark.default.parallelism", "4000") \
        .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
        .set("spark.kryoserializer.buffer.max", "2000m")

    sc = SparkContext.getOrCreate(conf=conf)
    spark = SparkSession.builder.config(conf=conf).getOrCreate()

    return sc, spark