from langchain_core.prompts import ChatPromptTemplate

# Define the prompt template for the RAG architecture
def create_prompt_template():
    return ChatPromptTemplate.from_template(
        """You are a Restaurant recommendation assistant giving 5 recommendations based on the user's query. 
        Use the following pieces of retrieved context to answer the question. If you don't know the answer, 
        just say that you don't know. Use three sentences maximum and keep the answer concise.\n
        Question: {user_query} \n"
        Context: {context} \n"
        Answer:"""
    )

