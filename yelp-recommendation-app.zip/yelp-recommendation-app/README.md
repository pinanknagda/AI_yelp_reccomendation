# yelp-recommendation-app/yelp-recommendation-app/README.md

# Yelp Recommendation App

This project is a Yelp Recommendation application that utilizes PySpark for processing a dataset with over 1.8 million records. It converts review text into vector embeddings for a Retrieval-Augmented Generation (RAG) architecture and includes a front-end built with the Streamlit library for user interaction.

## Project Structure

```
yelp-recommendation-app
├── data
│   ├── yelp_academic_dataset_review.json
│   └── yelp_academic_dataset_business.json
├── src
│   ├── __init__.py
│   ├── config.py
│   ├── data_processing
│   │   ├── __init__.py
│   │   ├── spark_setup.py
│   │   ├── data_loader.py
│   │   └── data_cleaning.py
│   ├── embeddings
│   │   ├── __init__.py
│   │   ├── embeddings_setup.py
│   │   └── vector_store.py
│   ├── rag
│   │   ├── __init__.py
│   │   ├── rag_chain.py
│   │   └── prompt.py
│   ├── frontend
│   │   ├── __init__.py
│   │   └── app.py
│   └── utils
│       ├── __init__.py
│       └── helpers.py
├── .env
├── requirements.txt
└── README.md
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd yelp-recommendation-app
   ```

2. Create a virtual environment and activate it:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. Install the required packages:
   ```
   pip install -r requirements.txt
   ```

4. Set up environment variables in the `.env` file. You will need to include your OpenAI API key and any other necessary configurations.

## Usage

1. Start the Streamlit application:
   ```
   streamlit run src/frontend/app.py
   ```

2. Open your web browser and navigate to `http://localhost:8501` to interact with the application.

## Features

- Data processing using PySpark for handling large datasets.
- Vector embeddings for reviews using OpenAI's embedding model.
- RAG architecture for generating recommendations based on user queries.
- User-friendly interface built with Streamlit.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.